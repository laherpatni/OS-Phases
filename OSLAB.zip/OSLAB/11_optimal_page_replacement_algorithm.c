#include <stdio.h>

int main() {
    int n, f;
    printf("Enter length of reference string: ");
    scanf("%d", &n);

    int ref[n];
    printf("Enter reference string: ");
    for (int i = 0; i < n; i++)
        scanf("%d", &ref[i]);

    printf("Enter number of frames: ");
    scanf("%d", &f);

    int frame[f];
    for (int i = 0; i < f; i++)
        frame[i] = -1;

    int page_faults = 0;

    for (int i = 0; i < n; i++) {
        int page = ref[i];
        int hit = 0;

        for (int j = 0; j < f; j++) {
            if (frame[j] == page) {
                hit = 1;
                break;
            }
        }

        if (!hit) {
            int idx = -1;
            int farthest = -1;

            for (int j = 0; j < f; j++) {
                if (frame[j] == -1) {
                    idx = j;
                    break;
                }
                int k;
                for (k = i + 1; k < n; k++) {
                    if (ref[k] == frame[j]) {
                        if (k > farthest) {
                            farthest = k;
                            idx = j;
                        }
                        break;
                    }
                }
                if (k == n) { // never used again
                    idx = j;
                    farthest = 1e9;
                }
            }

            frame[idx] = page;
            page_faults++;
        }
    }

    printf("Total page faults (Optimal) = %d\n", page_faults);
    return 0;
}
