#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <string.h>

int main() {
    pid_t pid = fork();

    if (pid < 0) {
        perror("fork failed");
        return 1;
    }

    if (pid == 0) {
        // Child process
        printf("Child: PID = %d, PPID = %d\n", getpid(), getppid());

        int fd = open("demo.txt", O_CREAT | O_WRONLY | O_TRUNC, 0644);
        if (fd < 0) {
            perror("open failed");
            return 1;
        }

        const char *msg = "Hello from child via write system call\n";
        if (write(fd, msg, strlen(msg)) < 0) {
            perror("write failed");
        }

        close(fd);
        _exit(0); // child exits
    } else {
        // Parent process
        printf("Parent: PID = %d, Child PID = %d\n", getpid(), pid);
        int status;
        wait(&status);  // wait for child

        int fd = open("demo.txt", O_RDONLY);
        if (fd < 0) {
            perror("open failed");
            return 1;
        }

        char buf[256];
        ssize_t n = read(fd, buf, sizeof(buf) - 1);
        if (n < 0) {
            perror("read failed");
        } else {
            buf[n] = '\0';
            printf("Parent read from file:\n%s", buf);
        }

        close(fd);
    }

    return 0;
}
