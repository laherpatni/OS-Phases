#!/bin/bash

echo "Enter a string:"
read str

len=${#str}
rev=""

# reverse the string character by character
for (( i=$len-1; i>=0; i-- ))
do
    rev="$rev${str:$i:1}"
done

# compare original and reversed strings
if [ "$str" = "$rev" ]; then
    echo "$str is a palindrome."
else
    echo "$str is not a palindrome."
fi

