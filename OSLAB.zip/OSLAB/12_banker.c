#include <stdio.h>

int main() {
    int p, r;
    printf("Enter number of processes: ");
    scanf("%d", &p);
    printf("Enter number of resource types: ");
    scanf("%d", &r);

    int alloc[p][r], max[p][r], need[p][r], avail[r];

    printf("Enter Allocation matrix:\n");
    for (int i = 0; i < p; i++)
        for (int j = 0; j < r; j++)
            scanf("%d", &alloc[i][j]);

    printf("Enter Max matrix:\n");
    for (int i = 0; i < p; i++)
        for (int j = 0; j < r; j++)
            scanf("%d", &max[i][j]);

    printf("Enter Available resources:\n");
    for (int j = 0; j < r; j++)
        scanf("%d", &avail[j]);

    // Need = Max - Allocation
    for (int i = 0; i < p; i++)
        for (int j = 0; j < r; j++)
            need[i][j] = max[i][j] - alloc[i][j];

    int finish[p];
    for (int i = 0; i < p; i++)
        finish[i] = 0;

    int safeSeq[p];
    int count = 0;

    while (count < p) {
        int found = 0;
        for (int i = 0; i < p; i++) {
            if (!finish[i]) {
                int j;
                for (j = 0; j < r; j++) {
                    if (need[i][j] > avail[j])
                        break;
                }
                if (j == r) {
                    // can be satisfied
                    for (int k = 0; k < r; k++)
                        avail[k] += alloc[i][k];

                    safeSeq[count++] = i;
                    finish[i] = 1;
                    found = 1;
                }
            }
        }
        if (!found) {
            printf("System is NOT in a safe state (no safe sequence).\n");
            return 0;
        }
    }

    printf("System is in a SAFE state.\nSafe sequence: ");
    for (int i = 0; i < p; i++)
        printf("P%d ", safeSeq[i]);
    printf("\n");

    return 0;
}
