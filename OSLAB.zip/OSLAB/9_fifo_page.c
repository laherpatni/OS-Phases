#include <stdio.h>

int main() {
    int n, f;
    printf("Enter length of reference string: ");
    scanf("%d", &n);

    int ref[n];
    printf("Enter reference string: ");
    for (int i = 0; i < n; i++)
        scanf("%d", &ref[i]);

    printf("Enter number of frames: ");
    scanf("%d", &f);

    int frame[f];
    for (int i = 0; i < f; i++)
        frame[i] = -1;

    int page_faults = 0;
    int pos = 0;

    for (int i = 0; i < n; i++) {
        int page = ref[i];
        int hit = 0;

        for (int j = 0; j < f; j++) {
            if (frame[j] == page) {
                hit = 1;
                break;
            }
        }

        if (!hit) {
            frame[pos] = page;
            pos = (pos + 1) % f;
            page_faults++;
        }
    }

    printf("Total page faults (FIFO) = %d\n", page_faults);
    return 0;
}
