include <stdio.h>
include <pthread.h>
include <unistd.h>

int shared_data = 0;
int read_count = 0;

pthread_mutex_t mutex;      // protects read_count
pthread_mutex_t rw_mutex;   // provides mutual exclusion for writers

void *reader(void *arg) {
    int id = *(int *)arg;
    while (1) {
        // Entry section
        pthread_mutex_lock(&mutex);
        read_count++;
        if (read_count == 1) {
            pthread_mutex_lock(&rw_mutex);
        }
        pthread_mutex_unlock(&mutex);

        // Critical section (reading)
        printf("Reader %d reads shared_data = %d\n", id, shared_data);
        usleep(100000); // 0.1s

        // Exit section
        pthread_mutex_lock(&mutex);
        read_count--;
        if (read_count == 0) {
            pthread_mutex_unlock(&rw_mutex);
        }
        pthread_mutex_unlock(&mutex);

        usleep(200000); // 0.2s
    }
    return NULL;
}

void *writer(void *arg) {
    int id = *(int *)arg;
    while (1) {
        pthread_mutex_lock(&rw_mutex);

        // Critical section (writing)
        shared_data++;
        printf("Writer %d writes shared_data = %d\n", id, shared_data);
        usleep(150000); // 0.15s

        pthread_mutex_unlock(&rw_mutex);

        usleep(300000); // 0.3s
    }
    return NULL;
}

int main() {
    pthread_t rtid[3], wtid[2];
    int r_id[3] = {1, 2, 3};
    int w_id[2] = {1, 2};

    pthread_mutex_init(&mutex, NULL);
    pthread_mutex_init(&rw_mutex, NULL);

    for (int i = 0; i < 3; i++)
        pthread_create(&rtid[i], NULL, reader, &r_id[i]);
    for (int i = 0; i < 2; i++)
        pthread_create(&wtid[i], NULL, writer, &w_id[i]);

    for (int i = 0; i < 3; i++)
        pthread_join(rtid[i], NULL);
    for (int i = 0; i < 2; i++)
        pthread_join(wtid[i], NULL);

    pthread_mutex_destroy(&mutex);
    pthread_mutex_destroy(&rw_mutex);

    return 0;
}
