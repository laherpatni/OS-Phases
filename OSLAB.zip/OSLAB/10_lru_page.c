#include <stdio.h>

int main() {
    int n, f;
    printf("Enter length of reference string: ");
    scanf("%d", &n);

    int ref[n];
    printf("Enter reference string: ");
    for (int i = 0; i < n; i++)
        scanf("%d", &ref[i]);

    printf("Enter number of frames: ");
    scanf("%d", &f);

    int frame[f], last_used[f];
    for (int i = 0; i < f; i++) {
        frame[i] = -1;
        last_used[i] = -1;
    }

    int page_faults = 0;

    for (int i = 0; i < n; i++) {
        int page = ref[i];
        int hit = 0;

        for (int j = 0; j < f; j++) {
            if (frame[j] == page) {
                hit = 1;
                last_used[j] = i;
                break;
            }
        }

        if (!hit) {
            int idx = -1, min_time = 1e9;
            for (int j = 0; j < f; j++) {
                if (frame[j] == -1) {
                    idx = j;
                    break;
                }
                if (last_used[j] < min_time) {
                    min_time = last_used[j];
                    idx = j;
                }
            }
            frame[idx] = page;
            last_used[idx] = i;
            page_faults++;
        }
    }

    printf("Total page faults (LRU) = %d\n", page_faults);
    return 0;
}
