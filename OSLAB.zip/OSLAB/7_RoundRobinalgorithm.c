#include <stdio.h>

typedef struct {
    int pid, at, bt;
    int ft, tat, wt;
    int rem_bt;
} Process;

int main() {
    int n, tq;
    printf("Enter number of processes: ");
    scanf("%d", &n);
    printf("Enter time quantum: ");
    scanf("%d", &tq);

    Process p[n];
    for (int i = 0; i < n; i++) {
        p[i].pid = i + 1;
        printf("Enter AT and BT for P%d: ", i + 1);
        scanf("%d%d", &p[i].at, &p[i].bt);
        p[i].rem_bt = p[i].bt;
    }

    int time = 0, done;
    int completed = 0;
    float total_tat = 0, total_wt = 0;

    while (completed < n) {
        done = 1;
        for (int i = 0; i < n; i++) {
            if (p[i].rem_bt > 0 && p[i].at <= time) {
                done = 0;

                if (p[i].rem_bt > tq) {
                    time += tq;
                    p[i].rem_bt -= tq;
                } else {
                    time += p[i].rem_bt;
                    p[i].ft = time;
                    p[i].tat = p[i].ft - p[i].at;
                    p[i].wt = p[i].tat - p[i].bt;
                    p[i].rem_bt = 0;
                    completed++;

                    total_tat += p[i].tat;
                    total_wt += p[i].wt;
                }
            }
        }
        if (done) {
            time++;
        }
    }

    printf("\nPID\tAT\tBT\tFT\tTAT\tWT\n");
    for (int i = 0; i < n; i++) {
        printf("P%d\t%d\t%d\t%d\t%d\t%d\n", p[i].pid, p[i].at, p[i].bt,
               p[i].ft, p[i].tat, p[i].wt);
    }

    printf("\nAverage TAT = %.2f\n", total_tat / n);
    printf("Average WT  = %.2f\n", total_wt / n);

    return 0;
}
